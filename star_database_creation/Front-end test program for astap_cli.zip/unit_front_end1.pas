unit unit_front_end1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, process, Forms, Controls, Graphics, Dialogs, StdCtrls, Windows;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Edit1: TEdit;
    Label1: TLabel;
    Memo1: TMemo;
    OpenDialog1: TOpenDialog;

    procedure Button1Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

var
  filename2: string='';
  LoadFITSPNGBMPJPEG1filterindex: integer=1;


{$ifdef mswindows}
function ExecuteAndWait(const aCommando: string; show_console: boolean): Integer;
var
  tmpStartupInfo: TStartupInfo;
  tmpProcessInformation: TProcessInformation;
  tmpProgram: String;
  dwExitCode: DWORD;
begin
  Result := -1;
  tmpProgram := trim(aCommando);
  FillChar(tmpStartupInfo, SizeOf(tmpStartupInfo), 0);
  with tmpStartupInfo do
  begin
    cb := SizeOf(TStartupInfo);
    if show_console = false then
    begin
      dwFlags := STARTF_USESHOWWINDOW;
      wShowWindow := SW_SHOWMINNOACTIVE;//SW_SHOWMINIMIZED which causes it to steal keyboard focus from active window. SW_SHOWMINNOACTIVE which opens the window the same way minimized but does not steal focus?
    end
    else
      wShowWindow := SW_HIDE;
  end;

  if CreateProcess(nil, PChar(tmpProgram), nil, nil, True,  CREATE_DEFAULT_ERROR_MODE or CREATE_NEW_CONSOLE or NORMAL_PRIORITY_CLASS,  nil, nil, tmpStartupInfo, tmpProcessInformation) then
  begin // loop every 100 ms
    while WaitForSingleObject(tmpProcessInformation.hProcess, 100) = WAIT_TIMEOUT do
      Application.ProcessMessages;

    // *** Retrieve the exit code ***
    if GetExitCodeProcess(tmpProcessInformation.hProcess, dwExitCode) then
      Result := Integer(dwExitCode);

    CloseHandle(tmpProcessInformation.hProcess);  // use CloseHandle, not FileClose
    CloseHandle(tmpProcessInformation.hThread);
  end
  else
    RaiseLastOSError;
end;

{$else} {unix}

procedure execute_unix(const execut: string; param: TStringList; show_output: boolean): Integer;
var
  AProcess: TProcess;
  AStringList: TStringList;
begin
  stackmenu1.Memo2.lines.add('Solver command:' + execut+' '+ param.commatext);
  {activate scrolling Memo3}
  stackmenu1.memo2.SelStart:=Length(stackmenu1.memo2.Lines.Text);
  stackmenu1.memo2.SelLength:=0;

  Application.ProcessMessages;

  Result := -1;
  AStringList := TStringList.Create;
  AProcess := TProcess.Create(nil);
  try
    AProcess.Executable := execut;
    AProcess.Parameters := param;
    AProcess.Options := [poUsePipes, poStderrToOutPut];
    AProcess.Execute;

    repeat
      wait(100); {smart sleep}
      if (AProcess.Output <> nil) and show_output
        and (AProcess.Output.NumBytesAvailable > 0) then
      begin
        AStringList.LoadFromStream(AProcess.Output);
        stackmenu1.Memo2.Lines.Add(AStringList.Text);
      end;
      Application.ProcessMessages;
    until (not AProcess.Running) or esc_pressed;

    // *** Retrieve the exit code ***
    Result := AProcess.ExitStatus;

  finally
    AProcess.Free;
    AStringList.Free;
  end;
end;


function execute_unix2(s: string): Integer;
var
  ex: integer;
begin
  ex := fpSystem(s);
  Result := wExitStatus(ex);   // decode the raw wait() status into the actual exit code
  if Result > 3 then
    ShowMessage('Exit code: ' + IntToStr(Result));
end;
{$endif}



procedure TForm1.Button1Click(Sender: TObject);
var
   i,countsolve, countfail : integer;
   mess : string;
begin
  OpenDialog1.Title := 'Open in viewer';
  opendialog1.Filter :=  'All formats |*.fit;*.fits;*.FIT;*.FITS;*.fts;*.FTS;*.png;*.PNG;*.jpg;*.JPG;*.bmp;*.BMP;*.tif;*.tiff;*.TIF;*.new;*.ppm;*.pgm;*.pbm;*.pfm;*.xisf;*.fz;'+
                                      '|FITS files (*.fit*,*.xisf)|*.fit;*.fits;*.FIT;*.FITS;*.fts;*.FTS;*.new;*.xisf;*.fz'+
                         '|PNG, TIFF, JPEG, BMP(*.png,*.tif*, *.jpg,*.bmp)|*.png;*.PNG;*.tif;*.tiff;*.TIF;*.jpg;*.JPG;*.bmp;*.BMP';
  opendialog1.filename:=filename2;
  opendialog1.initialdir:=ExtractFileDir(filename2);
  opendialog1.filterindex:=LoadFITSPNGBMPJPEG1filterindex;

  countsolve:=0;
  countfail:=0;
  if opendialog1.Execute then
  begin
    Screen.Cursor:=crHourglass;
    for i:=0 to OpenDialog1.Files.Count - 1 do
    begin
      if ExecuteAndWait(edit1.text+' -f "'+OpenDialog1.Files[i]+'"',false)=0 then
      begin
       inc(countsolve);
       mess:='Solved  ';
      end
      else
      begin
        inc(countfail);
        mess:='Failed  ';
      end;

      label1.Caption:='Succes '+inttostr(countsolve)+'   Failed '+inttostr(countfail);;
      memo1.Lines.add(TimeToStr(time) + '  ' + mess+OpenDialog1.Files[i]); {fill memo2 with log}
      application.processmessages;
    end;
    Screen.Cursor:=crDefault;
    memo1.Lines.add(TimeToStr(time) + '  '+'Ready');
  end;
end;

end.

