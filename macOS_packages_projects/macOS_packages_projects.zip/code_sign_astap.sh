#!/bin/bash
xattr -cr "/Applications/ASTAP.app"
codesign --force --deep -s - "/Applications/ASTAP.app"
exit 0
