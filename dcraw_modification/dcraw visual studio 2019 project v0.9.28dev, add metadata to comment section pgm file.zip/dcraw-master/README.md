dcraw modified
=====


Dcraw native builds for Windows OS 

[dcraw C source code](https://www.cybercom.net/~dcoffin/dcraw/dcraw.c)


   dcraw.c -- Dave Coffin's raw photo decoder
   Copyright 1997-2018 by Dave Coffin, dcoffin a cybercom o net

   This is a command-line ANSI C program to convert raw photos from
   any digital camera on any computer running any operating system.

   

Version 9.28 Revision 1.478 


http://www.cybercom.net/~dcoffin/dcraw/



## Features
	    
dcraw windows native 32 bits build by Olivier Levon, JPEG / LCMS / Jasper support included and patch for use with [ImageMagick]
	    
http://www.imagemagick.org/discourse-server/viewtopic.php?f=3&t=11183




## Requirements

Redistributable Microsoft Visual C++ for Visual Studio 2017 freely available from here: 

https://www.visualstudio.com/downloads/ (bottom of the page)

or direct links :

X64 https://go.microsoft.com/fwlink/?LinkId=746572

x86 https://go.microsoft.com/fwlink/?LinkId=746571