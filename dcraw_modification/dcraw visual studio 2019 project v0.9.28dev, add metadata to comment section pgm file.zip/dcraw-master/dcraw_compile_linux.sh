gcc -o dcraw -O3 dcraw.c -lm -NODEPS
